# AAPES Policy Engineering — skills-only plugin

This portable ChatGPT/Codex plugin bundles **one AAPES governance skill** and a read-only reference copy of the AAPES v2.1 English Agent Pack. It does not connect to any external MCP server or deploy runtime enforcement controls.

## Skill trigger

Ask to design, review, test, score or audit AI agent policies, authority, tool permissions, risk gates or evidence. The skill instructs an agent to use the 12 domains, 48 requirement IDs, and appropriate status/evidence separation.

## Bundled resources

- `skills/aapes-policy-engineering/SKILL.md` — entry point.
- `skills/aapes-policy-engineering/references/` — targeted workflows, quick reference, Arabic Word and learning notes.
- `skills/aapes-policy-engineering/resources/aapes-v2.1/` — exact English source pack: specification, framework, sample policies, schemas, scripts and tests.

## Local static checks (optional)

```bash
cd skills/aapes-policy-engineering/resources/aapes-v2.1
python -m pip install -r requirements.txt
python tools/validate_pack.py
python -m pytest -q
```

These only assess schemas and synthetic reference fixtures, not a live LLM or gateway. OPA tests require the installed `opa` executable. Production approval is never conferred by the plugin.

Plugin package version: 2.1.1. Based on AAPES v2.1 RC; this plugin packaging is not an independent standards certification.
