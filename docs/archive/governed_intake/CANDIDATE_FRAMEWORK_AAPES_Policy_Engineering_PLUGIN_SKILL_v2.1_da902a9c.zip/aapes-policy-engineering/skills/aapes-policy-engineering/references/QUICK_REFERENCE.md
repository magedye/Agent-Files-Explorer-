# AAPES quick reference

**Source:** AAPES v2.1 review candidate (AAPES-STD-002). This is proposed internal engineering guidance, not a certification.

| Domain | Focus | Importance (%) | R3 impact | Base priority |
|---|---|---:|---:|---|
| D01 | Requirements Engineering | 11 | 1.1 | P0 |
| D02 | Formal Semantics and Invariants | 9 | 1.2 | P0 |
| D03 | Instruction Authority and Conflict Resolution | 9 | 1.2 | P0 |
| D04 | Context Engineering and Few-Shot | 5 | 0.8 | P1 |
| D05 | Trust and Memory Boundaries | 10 | 1.5 | P0 |
| D06 | Agent Authority and Delegation | 10 | 1.5 | P0 |
| D07 | Tool Boundary Enforcement | 13 | 1.5 | P0 |
| D08 | Workflow and Recovery Governance | 6 | 1.3 | P1 (P0 for R2/R3) |
| D09 | Evidence Provenance and Audit | 9 | 1.1 | P0 |
| D10 | Evaluation and Calibration | 9 | 1.2 | P0 |
| D11 | Adversarial Testing and Resilience | 5 | 1.4 | P1 (P0 for R2/R3) |
| D12 | Lifecycle and Change Governance | 4 | 0.9 | P1 |

Weights are a proposed prioritization rubric, **not** reliability percentages or proven risk-reduction statistics.

**Risk tiers:** R0 advisory; R1 authorized read; R2 nonproduction mutations; R3 production/critical/irreversible. Reclassify whenever impact requires.

**Diagnostic maturity:** 0–4. `score = 100 × Σ(Wi × Ii × Mi/4) / Σ(Wi × Ii)` after permitted N/A handling. Provisional thresholds: R0 75; R1 80; R2 85; R3 90. All P0 veto checks are separate from score.

**Gates:** G0 risk/scope, G1 specification, G2 authority/conflicts, G3 enforceable controls, G4 tests, G5 evidence, G6 authorized review/approval, G7 activation/monitoring. A passing test ≠ independent verification ≠ approval ≠ activation.

**Minimum output states:** `DRAFT`, `BLOCKED`, `INCONCLUSIVE`, `VERIFIED_IN_SCOPE`, `READY_FOR_AUTHORIZED_REVIEW`, `ACTIVE` only after external platform activation evidence.

**Security:** tool schema ≠ authorization. LLM judge ≠ independent proof. Hash ≠ source authenticity. Prompt ≠ PEP. Machine-readable policy source ≠ verified runtime policy.
