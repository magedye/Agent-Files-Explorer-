# AAPES workflows (skill operator guide)

## AUTHOR

**Inputs:** objectives, existing constraints, platform/agent, environment, tool actions, policy owner, sources, optional previous policies. Missing fields remain `UNKNOWN`; do not fabricate authority.

**Steps:**
1. Intake and classify risk R0-R3. Identify data sensitivity and side effects separately; an R0/R1 classification does not mean zero confidentiality risk.
2. Identify normative governing policy and resolve supersession based on authority + scope + explicit replacement, not recency alone.
3. Produce one record per atomic requirement. Use `MUST`/`MUST NOT` for objectively testable obligations, `SHOULD` with an explicit deviation process, `MAY` for optional behaviors.
4. State if/then/else and unknown-result handling. Specify error and timeout branches; do not use broad 'always accurate' or 'fully secure'.
5. Bind each important requirement to enforcement owner, PEP/PDP or code check, test case, observable evidence, and approver. Risk-tier P0 controls must not be reduced to prompt instructions.
6. Add conflicts, known gaps, version and review state.

**Outputs:** atomic rule register; policy draft (see [RULE_TEMPLATE.md](RULE_TEMPLATE.md)); explicit evidence/test matrix; unresolved questions and review gates.

## REVIEW

Do **not** modify source policies unless explicitly asked. Establish version/commit and compare actual content to the 48 requirement IDs in [`framework.yaml`](../resources/aapes-v2.1/framework.yaml).

Check in order:
- Authority provenance and correct environment scope; no untrusted content promoted to instructions.
- Logical completeness: trigger, fallback, UNKNOWN, exceptions, contradictions, invariants.
- Identity/approval claims derived outside LLM, least privilege, delegation bounds and expiry.
- Non-bypassable tool gateway for R2/R3; fail-closed state-change paths.
- Safe recovery; not every action is reversible or has a sound Saga compensation.
- Real evidence lineage, secrets redaction, test execution and independent approval separated.
- Requalification after changed model, tool privileges, policy or environment.

Report findings as `ID / priority / rule / failure scenario / evidence / fix / acceptance test / authority`. Do not assert conformity without inspection.

## EVALUATE

1. Define test oracle **before** changing the prompt. Separate deterministic checks (syntax, schema, policy predicates) from semantic judgment.
2. Cover positive, negative, unknown, expired, replay, authority-conflict, misleading retrieved content, tool failures and authorization bypass attempts.
3. Use separate development, validation and untouched holdout sets. Compare variants on the same cases and report the sample size, setup, reruns and failure classes.
4. Calibrate LLM judges against blinded expert samples. Using another model family may help but is not sufficient or universally necessary.
5. For critical rules, every specified critical acceptance case must pass **within the assessed scope**, while noting that this is not a universal future guarantee.
6. Preserve test calls and tool outcomes; unavailable means `NOT_RUN`, not `PASS`.

**Outputs:** test matrix, run ledger, observed pass/fail/inconclusive rates (only when actually measured), confidence/limits and follow-up regression plan.

## ASSESS

1. Read [`framework.yaml`](../resources/aapes-v2.1/framework.yaml) for weights (12 domains, total 100), risk impact multipliers and risk-tier provisional thresholds.
2. Validate a structured input with [`schemas/assessment.schema.json`](../resources/aapes-v2.1/schemas/assessment.schema.json), if tooling is available.
3. Calculate **DiagnosticScore** separately from **HardGateDecision**. On any critical untested/failing gate, return `BLOCKED` while preserving the computed score.
4. Check independent evidence, provenance and risk-owner approval; do not accept user or model claims about external signatures without trusted verification.
5. The calculator's most favorable status is `READY_FOR_AUTHORIZED_REVIEW` and **never** constitutes activation.

**Outputs:** risk class, maturity-by-domain, weighted diagnostic score (provisional, not empirical), blocking gates, evidence status and next authorized decision.

## EXPLAIN

Teach in accessible Arabic or English using concrete examples, separating truth and simplification. Recommend a next learning concept only when it materially helps (e.g., instruction semantics versus policy enforcement). Keep the user's existing AI knowledge registry IDs stable; suggest new IDs only after checking current registry, never overwrite it from this skill automatically.
