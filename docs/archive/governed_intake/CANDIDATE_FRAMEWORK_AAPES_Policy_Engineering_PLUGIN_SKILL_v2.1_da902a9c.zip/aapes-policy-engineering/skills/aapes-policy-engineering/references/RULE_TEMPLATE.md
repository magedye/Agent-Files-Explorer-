# Draft policy template

Use **[RULE_TEMPLATE.yaml](RULE_TEMPLATE.yaml)** as a schema-valid starting point. It deliberately declares `status: DRAFT`, `implementation_status: NOT_CONNECTED`, and no verified owner approval. Replace example identities, risk tier, scope, authorization predicates and acceptance tests with trusted project facts.

Validate the structural shape against the canonical **[policy.schema.json](../resources/aapes-v2.1/schemas/policy.schema.json)**. A valid YAML structure does **not** prove that the tests ran, the predicates are enforceable or the approval was granted.

For a worked example with synthetic decision fixtures and a deterministic reference oracle, use **[test_evidence.yaml](../resources/aapes-v2.1/rules/test_evidence.yaml)**.
