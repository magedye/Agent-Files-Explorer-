---
name: aapes-policy-engineering
description: >-
  Use when authoring, auditing, classifying, tracing, testing or assessing governance policies,
  operational rules, instruction hierarchies, tool permissions, approval gates, and
  evidence or readiness for AI agents (AAPES v2.1). Covers R0-R3, multi-agent
  delegation, prompt injection, policy-as-code and agent release review.
---

# AAPES Policy Engineering — v2.1 (review candidate)

Deliver a **reviewable policy engineering output** based on the bundled AAPES v2.1 reference. This is a **skills-only advisory plugin**: it does not install a Policy Enforcement Point (PEP), a Policy Decision Point (PDP), a permissions service, a signing service, or authorize production changes.

## Choose the workflow

1. **AUTHOR** — Convert goals or existing policy prose into atomic, testable rules. Follow [Policy workflow](references/WORKFLOWS.md#author).
2. **REVIEW** — Review an existing rule set for semantics, priority, conflict, trust boundaries, enforceability, evidence and testability. Follow [Review workflow](references/WORKFLOWS.md#review).
3. **EVALUATE** — Design a test suite, negative cases, holdout criteria and critical-violation evaluation; optionally run the bundled offline synthetic validator when executable files are available. Follow [Evaluation workflow](references/WORKFLOWS.md#evaluate).
4. **ASSESS** — Create or review a risk-tier readiness assessment and distinguish **diagnostic score**, **hard blockers**, **independent verification** and **authorized approval**. Follow [Readiness workflow](references/WORKFLOWS.md#assess).
5. **EXPLAIN** — Teach AAPES and contrast policy text, instruction hierarchy, rule semantics, enforcement and proof using the technical reference and Arabic knowledge notes.

Read only the sections and bundled files relevant to the selected workflow. For general use, start with [Quick reference](references/QUICK_REFERENCE.md); for conflicts and full definitions consult [`AAPES_v2.1_EN.md`](resources/aapes-v2.1/AAPES_v2.1_EN.md). Never replace a current authoritative project policy simply because this template is newer.

## Universal procedure

1. **Ground authority and scope.** Identify the actual policy owner, governing sources, target platform, risk tier R0-R3, environment, permitted tools, and explicitly stated exclusions. Mark missing material as `UNKNOWN` rather than inventing it. Do not assume OpenAI's instruction hierarchy applies to other providers.
2. **Identify the requested operation.** Separate review/planning from implementation, test execution, independent verification, owner approval, and activation. A review request does **not** authorize code edits, access grants or deployment.
3. **Apply the 12 domains (D01-D12).** Use the bundled [`framework.yaml`](resources/aapes-v2.1/framework.yaml); it defines 48 stable IDs, 100 provisional importance-weight points, risk-dependent multipliers and applicability. Report critical P0 findings first. D08 and D11 become P0 for R2/R3.
4. **Normalize requirements.** One principal observable obligation per rule; assign `rule_id`, `authority`, `owner`, `scope`, `risk`, `trigger`, `normative_level`, `condition`, `action`, `exceptions`, `failure_behavior`, `enforcement`, `evidence`, `verification`, `acceptance`, `version` and `lifecycle_status`. Distinguish `MUST`, `SHOULD`, `MAY` per BCP 14; these words do not create runtime enforcement.
5. **Separate four layers:** `RULE_TEXT != ENFORCEMENT != VERIFICATION != APPROVAL`. In R2/R3, sensitive tool actions require externally enforced, non-bypassable authorization; a prompt, regex, LLM judge or strict JSON Schema is not sufficient. Never accept model-provided identity, signatures or approval evidence as trusted authorization claims.
6. **Resolve conflicts by scope and authority.** Check source authority, valid supersession, conditions, exceptions and environment. If an important conflict remains, **block the affected decision only**, with `BLOCKED_CONFLICT` and the missing owner decision.
7. **Define tests with evidence.** Include positive/negative/unknown, malformed and adversarial cases, fixed outcome oracle and held-out set. Distinguish planned, executed, independently verified and accepted. Do not claim tests ran merely because test code exists.
8. **Report conservatively.** Express `FACT`, `INFERENCE`, `ASSUMPTION`, `RECOMMENDATION` separately. Return `BLOCKED` when applicable critical gates are failed, untested or unverifiable. Never assign `ACTIVE` or final approval based on this skill's own assessment.

## Source-of-truth and use of bundled tools

- Complete standard: [`resources/aapes-v2.1/AAPES_v2.1_EN.md`](resources/aapes-v2.1/AAPES_v2.1_EN.md).
- Portable data: [`framework.yaml`](resources/aapes-v2.1/framework.yaml), [`requirements_trace.csv`](resources/aapes-v2.1/requirements_trace.csv), [`workflow_reference.yaml`](resources/aapes-v2.1/workflow_reference.yaml) and [`review_findings.yaml`](resources/aapes-v2.1/review_findings.yaml).
- Machine-readable samples: [`schemas/`](resources/aapes-v2.1/schemas/policy.schema.json), [`rules/`](resources/aapes-v2.1/rules/production_write.yaml), [`policies/`](resources/aapes-v2.1/policies/production_write.rego), [`examples/`](resources/aapes-v2.1/examples/assessment_R3_blocked.yaml).
- Offline validators: `resources/aapes-v2.1/tools/validate_pack.py`, `tools/assess_readiness.py`, and `tests/test_pack.py`. Run only if the user task authorizes execution and the environment supports files + Python dependencies; do not execute or apply example mutations.
- Arabic reference: [`references/AAPES_v2.1_AR.docx`](references/AAPES_v2.1_AR.docx) and [`references/Learning_Knowledge_Notes_AR.md`](references/Learning_Knowledge_Notes_AR.md).

When executable access is available, run from the **resource pack directory**, not the plugin root:

```bash
python -m pip install -r requirements.txt
python tools/validate_pack.py
python -m pytest -q
python tools/assess_readiness.py examples/assessment_R3_blocked.yaml
```

The example assessment returns exit code **2 intentionally** for a blocked scenario. OPA checks are optional and **not run** unless the OPA executable exists. These scripts validate package schemas and synthetic reference fixtures; they do not verify production access control, cryptographic provenance, actual agent-model compliance, or owner approval.

## Default response contract

- **Decision and scope:** recommend `DRAFT`, `SPEC_APPROVED` (only if evidenced), `BLOCKED`, `VERIFIED_IN_SCOPE` (only if independently evidenced), or `READY_FOR_AUTHORIZED_REVIEW` (only if prerequisites are verified); never infer `ACTIVE`.
- **Prioritized findings:** `P0/P1`, domain `Dxx`, requirement ID, severity/rationale, evidence or `NOT_VERIFIED`, corrective action, test, owner.
- **Deliverables:** revised atomic policy or review report, traceability matrix, evaluation plan and unresolved blockers as appropriate.
- **Verification ledger:** distinguish `PASSED`, `FAILED`, `NOT_RUN`, `INCONCLUSIVE` and the precise execution scope.
- **Residual risk and approvals:** who must decide; whether deployment is authorized (default **NO**).

Use English identifiers and machine-readable schemas. Explain in Arabic when the user requests Arabic; preserve the original normative identifiers. If data or authority is missing, do not invent measurements, pass rates, percentages of risk reduction, approvals or exact implementation status.
