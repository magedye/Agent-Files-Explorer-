#!/usr/bin/env python3
"""Static AAPES package validation and synthetic reference fixtures.

Does not evaluate a model, authorize a tool, verify signatures, or certify a PEP.
"""
import json, shutil, subprocess, sys
from pathlib import Path
import yaml
from jsonschema import Draft202012Validator
from reference_guard import ORACLES

ROOT=Path(__file__).resolve().parents[1]

def load_json(name):
    return json.loads((ROOT/name).read_text(encoding='utf-8'))

def load_yaml(name):
    return yaml.safe_load((ROOT/name).read_text(encoding='utf-8'))

def validate(verbose=True):
    fw=load_yaml('framework.yaml')
    assert fw['status']=='REVIEW_CANDIDATE_NOT_ADOPTED'
    domains=fw['domains']
    assert len(domains)==12 and len({x['id'] for x in domains})==12
    assert sum(x['importance_weight_percent'] for x in domains)==100
    for risk in fw['risk_levels']:
        assert all(0.5 <= d['impact_multiplier_by_risk'][risk] <= 1.5 for d in domains)
    requirements=[x for d in domains for x in d['requirements']]
    ids={x['id'] for x in requirements}
    assert len(requirements)==48 and len(ids)==48
    assert ids=={f'AAPES-REQ-{i:03d}' for i in range(1,49)}
    assert len(load_yaml('review_findings.yaml'))>=12
    for schema_file in sorted((ROOT/'schemas').glob('*.json')):
        Draft202012Validator.check_schema(load_json(schema_file.relative_to(ROOT)))
    policy_schema=load_json('schemas/policy.schema.json')
    validator=Draft202012Validator(policy_schema)
    cases=0
    for f in sorted((ROOT/'rules').glob('*.yaml')):
        policy=yaml.safe_load(f.read_text(encoding='utf-8'))
        errs=list(validator.iter_errors(policy))
        assert not errs, f'{f.name}: '+ '; '.join(str(x) for x in errs)
        assert policy['status']=='DRAFT', f'{f.name}: no rule shall claim approved/active'
        assert policy['enforcement']['implementation_status']=='NOT_CONNECTED'
        assert all(r in ids for r in policy['references'])
        testlist=policy['verification']['tests']
        assert len({x['id'] for x in testlist})==len(testlist)
        func=ORACLES.get(policy['rule_id'])
        assert func is not None, f'{policy["rule_id"]}: no reference oracle'
        for t in testlist:
            answer=func(t['input'])
            assert answer==t['expected'], f'{policy["rule_id"]}:{t["id"]} got {answer}, wanted {t["expected"]}'
            cases+=1
        if verbose: print(f'STATIC PASS: {policy["rule_id"]} ({len(testlist)} synthetic fixtures)')
    # No artificial claim of OPA run if unavailable.
    opa=shutil.which('opa')
    opa_result='NOT_RUN: OPA binary unavailable'
    if opa:
        check=subprocess.run([opa,'check','policies/production_write.rego','policies/production_write_test.rego'],cwd=ROOT,capture_output=True,text=True)
        if check.returncode: raise AssertionError('opa check failed: '+check.stderr)
        test=subprocess.run([opa,'test','policies/production_write.rego','policies/production_write_test.rego'],cwd=ROOT,capture_output=True,text=True)
        if test.returncode: raise AssertionError('opa test failed: '+test.stdout+test.stderr)
        opa_result='PASS: opa check + opa test (reference policy only)'
    if verbose:
        print(f'STATIC PASS: 12 domains; 48 IDs; 100 weight points; {cases} deterministic synthetic cases')
        print(f'REGO STATUS: {opa_result}')
        print('NOT VERIFIED: production PEP/PDP, real approvals, cryptographic evidence, model compliance, live tools or deployment authorization.')
    return {'domains':len(domains),'requirements':len(requirements),'synthetic_cases':cases,'rego_status':opa_result}

if __name__=='__main__':
    try: validate()
    except Exception as exc:
        print('VALIDATION FAIL:',str(exc),file=sys.stderr)
        raise SystemExit(1)
