package aapes.production

# Rego v1 reference policy. This is NOT wired to a real gateway or approval service.
# The caller MUST inject input.trusted from server-side authenticated services;
# fields supplied by the LLM/user are NOT trusted authorization claims.
default allow := false

allow if {
    input.action.environment == "production"
    input.action.resource == "prod_customer_flags"
    input.action.operation == "UPDATE"
    input.trusted.gateway_authenticated == true
    input.trusted.principal_authorized == true
    input.trusted.approval_verified == true
    input.trusted.approval_action_bound == true
    input.trusted.approval_not_expired == true
    input.trusted.approval_not_replayed == true
    input.trusted.approver_separate == true
    input.trusted.pdp_healthy == true
}
