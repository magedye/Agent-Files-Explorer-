package aapes.production

# OPA test fixtures are mock inputs; the policy does NOT validate cryptographic signatures.
test_allow_only_when_all_verified if {
    allow with input as {
        "action": {"environment":"production", "resource":"prod_customer_flags", "operation":"UPDATE"},
        "trusted": {
            "gateway_authenticated":true, "principal_authorized":true,
            "approval_verified":true, "approval_action_bound":true,
            "approval_not_expired":true, "approval_not_replayed":true,
            "approver_separate":true, "pdp_healthy":true
        }
    }
}

test_deny_without_external_approval if {
    not allow with input as {
        "action": {"environment":"production", "resource":"prod_customer_flags", "operation":"UPDATE"},
        "trusted": {"gateway_authenticated":true,"principal_authorized":true,"approval_verified":false}
    }
}

test_deny_missing_trusted_context if {
    not allow with input as {
        "action": {"environment":"production", "resource":"prod_customer_flags", "operation":"UPDATE"}
    }
}
