# Change Log — AAPES v2.1.0-rc.1

**Lineage:** AAPES v1.0 agent pack -> user-supplied AAPES v2.0 draft -> this reviewed candidate.

## Added

- 12 additional atomic requirements (`AAPES-REQ-037` through `048`) without renumbering `001`–`036`.
- Risk-adjusted impact multipliers for R0–R3 with explicit uncalibrated-design notice.
- Strict model-originated action schema that rejects self-asserted approval credentials.
- Separate trusted gateway claim boundary and non-bypassable PEP integration requirement.
- Rego v1 reference policy and optional OPA tests with explicit `NOT_RUN` reporting.
- Approval scope/expiry/replay/segregation-of-duties requirements.
- Memory provenance, retention and access controls; idempotency and recovery requirements.
- Machine-readable approval-request, audit-event, and state-transition reference contracts.
- A 48-row requirements trace template and an explicit v1-to-v2.1 migration map.
- An English complete reference specification and auditable source draft review findings.

## Corrected

- Replaced unsupported `crypto.x509.verify_signature` pseudo-builtin with a gateway-side verified-claim contract; the included Rego policy is **not** a signature verifier.
- Replaced blanket `ROOT>SYSTEM>DEVELOPER>USER>TOOL_OUTPUT` for all vendors with platform-specific documented precedence and trust boundaries.
- Kept score and safety veto as separate values; unsafe designs do **not** receive deceptive `score=0` in lieu of diagnostics.
- Limited formal-DSL enforcement requirement to consequential R2/R3 authorizations where it is appropriate.
- Corrected claim that every Saga step has a safe reverse operation; supports irreversibility and `RECOVERY_REQUIRED`.
- Replaced fixed 70% context reset, 2500ms/10s timeouts, 5-strikes circuit breakers, 15/hour human alerts with measured configuration.
- Removed blanket cross-family LLM judge ban and mandatory fixed 10%/kappa=0.85 human-review formulas.
- Reworded `100% compliance` to **zero observed critical failures in the declared critical suite** plus coverage reporting.
- Separated JSON Schema structural validity from identity and authorization semantics.
- Added privacy/retention and evidence provenance to cryptographic logging proposals.

## Verification status of this release

- Python static checks and offline synthetic decision fixtures: executable and repeatable.
- Rego syntax tests: `NOT_RUN` when OPA is unavailable; must be tested at the adopter's environment.
- Live tool integration, actual authorization, cryptographic logs, behavioral AI model evaluations and production safety: **NOT VERIFIED**.
