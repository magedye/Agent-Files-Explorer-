# AAPES v2.1 — English Agent Pack

**AI Agent Policy Engineering Standard — reviewed engineering candidate**

- Standard ID: `AAPES-STD-002`
- Version: `2.1.0-rc.1` (2026-11-04)
- Status: `REVIEW_CANDIDATE_NOT_ADOPTED`
- Language of the pack: **English** (separate Arabic Word reference is delivered outside the pack).
- Source lineage: previous AAPES v1.0 package + user-supplied AAPES v2.0 draft, reviewed and corrected.

> **Security notice:** This repository is a **template/reference implementation**, not an integrated approval system, a hardened runtime or an ISO/OWASP certification. No script grants authority to act on production systems. Do not set `ACTIVE` because local unit tests pass.

## What is inside

| File | Purpose |
|---|---|
| `AAPES_v2.1_EN.md` | Complete normative and engineering specification in English |
| `framework.yaml` | Twelve domains, 100 design-weight points, impact multipliers, 48 stable requirement IDs, gates and risk tiers |
| `review_findings.yaml` | Traceable review of 17 material changes from v2.0 |
| `requirements_trace.csv` | Planned test/enforcement/evidence mapping for all 48 requirements; deliberately unverified |
| `migration_map.csv` | Preserves v1 requirement identifiers and documents added IDs |
| `schemas/policy.schema.json` | Strict draft policy format |
| `schemas/tool_action.schema.json` | Strict *model-proposed* tool action; **no approval/identity claims allowed** |
| `schemas/assessment.schema.json` | Shape of an unverified readiness assessment |
| `schemas/approval_request.schema.json` | Human approval **request** contract, not an approval grant |
| `schemas/audit_event.schema.json` | Audit event envelope; structural, not signature verification |
| `workflow_reference.yaml` | Mutating-workflow state transitions and recovery branches |
| `rules/production_write.yaml` | Example draft R3 policy with 11 offline decision fixtures |
| `rules/test_evidence.yaml` | Draft evidence-state classifier with 7 offline decision fixtures |
| `policies/production_write.rego` | **Unconnected** OPA Rego v1 default-deny reference policy |
| `policies/production_write_test.rego` | Example OPA language tests; require OPA installed to run |
| `tools/reference_guard.py` | Deterministic **synthetic** oracle; not a production PEP |
| `tools/validate_pack.py` | Schema/identifier/fixture checks, optional `opa check` / `opa test` |
| `tools/assess_readiness.py` | Computes diagnostic score + explicit hard blockers; never grants approval |
| `tests/test_pack.py` | Offline regression suite |
| `examples/assessment_R3_blocked.yaml` | Deliberately blocked R3 worked example |
| `CHANGELOG.md` | Changes and semantic corrections |
| `ADOPTION_CHECKLIST.md` | Actionable prerequisites before deployment |
| `requirements.txt` | Python dependencies |
| `VERIFICATION_REPORT.md` | Explicit pass/not-run scope and limitations |

## Run local checks

Requires Python 3.10+ and package dependencies. From this folder:

```bash
python -m pip install -r requirements.txt
python tools/validate_pack.py
python -m pytest -q
python tools/assess_readiness.py examples/assessment_R3_blocked.yaml
```

The final command intentionally returns **exit code 2** for `BLOCKED`. Do not interpret that as a malfunction. The sample should yield **score 50.0** with blockers.

**Optional OPA check** (install [OPA](https://www.openpolicyagent.org/docs/) separately, confirm tool version, then run):

```bash
opa check policies/production_write.rego policies/production_write_test.rego
opa test policies/production_write.rego policies/production_write_test.rego
```

If the OPA binary is not installed, `validate_pack.py` reports `REGO STATUS: NOT_RUN`; it never claims Rego tests passed. Rego tests operate on **mock trusted attributes**, not real cryptographic signatures. Before deployment, validate verified identity and ticket binding in an independently authenticated gateway, then confirm PEP unbypassability with integration tests.

## Core operating rules

1. Preserve the distinction: policy text != enforcement != verification != approval.
2. Derive identity, token scope, signature status, approval binding, expiry, and replay checks **outside** the model.
3. A strict JSON Schema restricts fields but does not prove authorization.
4. Deny side effects when authorization is missing, ambiguous, expired, replayed or unavailable.
5. Use a separate policy decision service and non-bypassable tool gateway for R2/R3.
6. Preserve an audit trail from exact policy/model/code versions to tool-side outcomes.
7. Evaluate on held-out positive, negative, unknown and adversarial cases; do not claim universal correctness.
8. Record who approved residual risk, when, for which exact environment and revision.

## Scoring and control gates

`DiagnosticScore = 100 * sum(weight * risk_impact * maturity/4) / sum(weight * risk_impact)`.

This is an **advisory design rubric**. Any applicable critical/P0 failure blocks qualification **without erasing the diagnostic score**. Every script output is self-reported and not independently authenticated. The strongest possible result from the calculator is `READY_FOR_AUTHORIZED_REVIEW` (a review of **controlled activation after risk sign-off**), never `ACTIVE`. The `owner_approval` input describes the G6 risk-acceptance record, not a substitute for the G7 operational activation decision.

## Constraints of this delivered package

- No production PEP/PDP, cryptographic signing service, identity provider, approval registry, agent runtime, CI interface or audit ledger is connected.
- Synthetic reference fixtures are not independent red-team results.
- Production readiness, ISO conformity and model-specific instruction adherence remain unverified.
- Organizational risk multipliers and acceptance thresholds still require authorized calibration.
