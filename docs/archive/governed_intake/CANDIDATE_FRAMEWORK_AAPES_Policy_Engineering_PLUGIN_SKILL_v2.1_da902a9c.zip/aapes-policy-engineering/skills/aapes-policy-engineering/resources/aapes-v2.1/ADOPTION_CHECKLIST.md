# AAPES Integration and Adoption Checklist

**This is an owner-controlled procedure, not an autonomous authorization for an agent to deploy.**

## G0 — Intake

- [ ] Record business intent, environment, risk tier, potential external effects, data classification and policy owner.
- [ ] Confirm that the claimed risk tier accounts for confidential data and downstream effects, not just tool mutation capability.

## G1 — Requirements

- [ ] Derive each atomic requirement, trigger, exception, unknown handling and observed acceptance condition.
- [ ] Link exact requirement IDs to tests, external control and authorized approver.

## G2 — Authority

- [ ] Record model/provider-specific instruction hierarchy and trusted/untrusted boundaries.
- [ ] Resolve policy conflicts and supersession, or stop only the impacted work.

## G3 — Real enforcement

- [ ] Install an independent, non-bypassable PEP for each side-effecting tool.
- [ ] Authenticate user and agent identities server-side; verify approval signature/binding and expiry outside LLM input.
- [ ] Use least privilege, scoped credentials, time limits, replay checks and rate limits.
- [ ] Test a bypass attempt with a forged trusted claim, blocked tool name and non-authorized resource.
- [ ] Make deny/fail-closed behavior observable when PDP/approval service is unavailable.

## G4 — Test execution

- [ ] Run syntax/schema checks and actual OPA `check` / `test` (or equivalent engine tests).
- [ ] Run tool integration tests using isolated but realistic service wiring.
- [ ] Execute positive, negative, incomplete-evidence, conflict, long-context and injection cases.
- [ ] Calibrate semantic judges on independently labeled and representative human decisions.
- [ ] Report number of cases, classes, confidence limits and observed critical failures.

## G5 — Evidence and recovery

- [ ] Capture action trace, policy/model/code revision, actual tool-side result and independent reviewer identity.
- [ ] Validate audit access restrictions, tamper-evidence, redaction, retention and key management.
- [ ] Test idempotent retries, compensation and manual recovery for non-reversible actions.

## G6 — Authorized approval

- [ ] Record a separate authorized human sign-off specifying exact risk acceptance, environment, version and expiry.
- [ ] Confirm approval has not been replayed or self-issued by the agent.

## G7 — Controlled activation

- [ ] Enable only approved operations/permissions; monitor runtime drift, outages and tool results.
- [ ] Exercise emergency stop, incident response, revocation and rollback/recovery runbooks.
- [ ] Requalify affected controls on model, tool, prompt, policy or permission changes.

**Stop rule:** missing data or unexecuted critical tests => `BLOCKED` / `INSUFFICIENT_EVIDENCE`; do not infer a PASS.
