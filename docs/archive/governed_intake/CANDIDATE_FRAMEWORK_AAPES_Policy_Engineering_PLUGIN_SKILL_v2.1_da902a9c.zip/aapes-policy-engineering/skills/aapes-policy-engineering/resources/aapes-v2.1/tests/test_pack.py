"""Offline AAPES reference unit tests. Real external integrations not exercised."""
import copy, json, sys
from pathlib import Path
import pytest,yaml
from jsonschema import Draft202012Validator
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
from reference_guard import production_write_reference,classify_test_evidence,TRUSTED_CLAIMS
from assess_readiness import evaluate
from validate_pack import validate
fw=yaml.safe_load((ROOT/'framework.yaml').read_text(encoding='utf-8'))
prod=yaml.safe_load((ROOT/'rules/production_write.yaml').read_text(encoding='utf-8'))
ass=yaml.safe_load((ROOT/'examples/assessment_R3_blocked.yaml').read_text(encoding='utf-8'))

def test_pack_structure():
    assert validate(verbose=False)['requirements']==48

@pytest.mark.parametrize('fixture',prod['verification']['tests'],ids=lambda f:f['id'])
def test_reference_fixtures(fixture):
    assert production_write_reference(fixture['input'])==fixture['expected']

def test_model_approval_claim_rejected():
    x=copy.deepcopy(prod['verification']['tests'][0]['input'])
    x['action']['approval_verified']=True # forged untrusted argument
    assert production_write_reference(x)=='DENY'

def test_missing_trusted_claim_denied():
    x=copy.deepcopy(prod['verification']['tests'][0]['input'])
    del x['trusted'][TRUSTED_CLAIMS[0]]
    assert production_write_reference(x)=='DENY'

def test_reference_result_inconclusive_for_missing_evidence():
    assert classify_test_evidence({'all_required_executed':True,'all_required_passed':True})=='INCONCLUSIVE'

def test_assessment_veto_separate_from_score():
    out=evaluate(fw,ass)
    assert out['qualification']=='BLOCKED'
    assert out['diagnostic_score']==50
    assert out['blocker_count']>0

def test_assessment_missing_gate_blocks_even_after_owner_claim():
    x=copy.deepcopy(ass)
    for d in x['scores'].values():
        d.update(maturity=4,evidence_refs=['TEST:fake'],verified_by='external reviewer',verification_ref='TEST:fake')
    x['veto_signals']={k:False for k in fw['critical_blocker_signals']}
    x['owner_approval']={'status':'GRANTED','approver':'Demo owner','approval_ref':'TEST:fake'}
    for g in x['gates'].values():
        g.update(status='PASS',evidence_refs=['TEST:fake'])
    x['gates']['G3']['status']='NOT_RUN'
    out=evaluate(fw,x)
    assert out['diagnostic_score']==100
    assert out['qualification']=='BLOCKED'
    assert any('G3' in s for s in out['blockers'])

def test_schema_rejects_unknown_fields():
    rule_schema=json.loads((ROOT/'schemas/policy.schema.json').read_text(encoding='utf-8'))
    p=copy.deepcopy(prod);p['unverified_special_privilege']=True
    assert not Draft202012Validator(rule_schema).is_valid(p)

def test_unapproved_sample_is_not_active():
    assert prod['status']=='DRAFT'
    assert prod['approval']['status']=='NOT_REQUESTED'
    assert prod['enforcement']['implementation_status']=='NOT_CONNECTED'

@pytest.mark.parametrize('case',yaml.safe_load((ROOT/'rules/test_evidence.yaml').read_text(encoding='utf-8'))['verification']['tests'],ids=lambda f:f['id'])
def test_evidence_reference_cases(case):
    assert classify_test_evidence(case['input'])==case['expected']

def test_approval_request_is_not_approval_grant():
    schema=json.loads((ROOT/'schemas/approval_request.schema.json').read_text(encoding='utf-8'))
    req=json.loads((ROOT/'examples/approval_request_R3_pending.json').read_text(encoding='utf-8'))
    assert Draft202012Validator(schema).is_valid(req)
    forged=copy.deepcopy(req);forged['approval_token']='INJECTED_BY_MODEL'
    assert not Draft202012Validator(schema).is_valid(forged)

def test_audit_sample_is_deny_no_execution():
    schema=json.loads((ROOT/'schemas/audit_event.schema.json').read_text(encoding='utf-8'))
    evt=json.loads((ROOT/'examples/audit_event_DENIED.json').read_text(encoding='utf-8'))
    assert Draft202012Validator(schema).is_valid(evt)
    assert evt['decision']=='DENY' and evt['execution_status']=='NOT_EXECUTED'
    assert evt['tamper_evidence_ref'] is None  # shape example, no integrity proof

def test_workflow_requires_independent_verification_before_commit():
    fsm=yaml.safe_load((ROOT/'workflow_reference.yaml').read_text(encoding='utf-8'))
    edges={(e['from'],e['to']) for e in fsm['transitions']}
    assert ('INDEPENDENTLY_VERIFIED','COMMITTED') in edges
    assert all(dst!='COMMITTED' or src=='INDEPENDENTLY_VERIFIED' for src,dst in edges)
    assert ('COMPENSATING','RECOVERY_REQUIRED') in edges

def test_traceability_register_is_explicitly_unverified():
    import csv
    with (ROOT/'requirements_trace.csv').open(encoding='utf-8',newline='') as f:
        rows=list(csv.DictReader(f))
    fwids={r['id'] for d in fw['domains'] for r in d['requirements']}
    assert len(rows)==48 and {r['requirement_id'] for r in rows}==fwids
    assert all(r['verification_status']=='NOT_RUN' and r['evidence_ref']=='NOT_AVAILABLE' for r in rows)

def test_migration_map_preserves_old_ids():
    import csv
    with (ROOT/'migration_map.csv').open(encoding='utf-8',newline='') as f:
        rows=list(csv.DictReader(f))
    assert len(rows)==48
    assert sum(r['change_type']=='CLARIFIED_PRESERVED' for r in rows)==36
    assert sum(r['change_type']=='ADDED' for r in rows)==12
