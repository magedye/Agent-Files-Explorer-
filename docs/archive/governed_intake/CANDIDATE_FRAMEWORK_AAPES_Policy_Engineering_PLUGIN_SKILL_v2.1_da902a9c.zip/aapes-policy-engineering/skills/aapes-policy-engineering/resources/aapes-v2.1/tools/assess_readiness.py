#!/usr/bin/env python3
"""Compute diagnostic maturity and hard blockers for an UNVERIFIED assessment.

This is NOT an approval/signature verifier. A passing declaration is always only
READY_FOR_AUTHORIZED_REVIEW, never ACTIVE or an authorization to deploy.
"""
import json,sys
from pathlib import Path
import yaml
from jsonschema import Draft202012Validator

ROOT=Path(__file__).resolve().parents[1]

def load_yaml(path):
    return yaml.safe_load(Path(path).read_text(encoding='utf-8'))

def evaluate(fw, assess):
    sch=json.loads((ROOT/'schemas/assessment.schema.json').read_text(encoding='utf-8'))
    Draft202012Validator(sch).validate(assess)
    risk=assess['risk_level']; scores=assess['scores']; blockers=[]
    num=den=0.0
    domain_details=[]
    for d in fw['domains']:
        did=d['id']; data=scores[did]; m=data['maturity']; w=d['importance_weight_percent'];impact=d['impact_multiplier_by_risk'][risk]
        p0 = d['priority_base']=='P0' or d['priority_if_risk'].get(risk)=='P0'
        if m=='NOT_APPLICABLE':
            permitted = (risk in ('R0','R1') and did in ('D08','D11'))
            if not permitted or not data['na_reason'] or not data['na_approved_by']:
                blockers.append(f'{did}: invalid/unapproved N/A exception')
            domain_details.append({'id':did,'maturity':m,'weight':w,'impact':impact,'p0':p0})
            continue
        den+=w*impact;num+=w*impact*(m/4)
        if m>=3 and not data['evidence_refs']:
            blockers.append(f'{did}: maturity {m} has no evidence references')
        if m==4 and (not data['verified_by'] or not data['verification_ref']):
            blockers.append(f'{did}: maturity 4 lacks named independent verification evidence')
        if p0 and risk in ('R2','R3') and m!=4:
            blockers.append(f'{did}: applicable P0 must be maturity 4 for {risk}')
        domain_details.append({'id':did,'maturity':m,'weight':w,'impact':impact,'p0':p0})
    score=round(100*num/den,2) if den else 0
    if den==0:blockers.append('All domains excluded; no scoring basis')
    threshold=fw['risk_levels'][risk]['minimum_readiness']
    if score<threshold:blockers.append(f'Diagnostic score {score} < provisional risk-tier threshold {threshold}')
    for key in fw['critical_blocker_signals']:
        if assess['veto_signals'][key] is not False:
            blockers.append(f'Critical safety signal {key}={assess["veto_signals"][key]} (FALSE required)')
    for gate in fw['qualification_required_gates'][risk]:
        v=assess['gates'][gate]
        if v['status']!='PASS':blockers.append(f'{gate}: required gate not PASS ({v["status"]})')
        elif not v['evidence_refs']:blockers.append(f'{gate}: PASS claim without evidence reference')
    approval=assess['owner_approval']
    if risk in ('R2','R3') and (approval['status']!='GRANTED' or not approval['approval_ref'] or not approval['approver']):
        blockers.append(f'{risk}: independent authorized owner approval is missing or incomplete')
    # Preserves diagnostic score even on veto. The tool never authenticates evidence.
    status='BLOCKED' if blockers else 'READY_FOR_AUTHORIZED_REVIEW'
    return {
        'standard_id':fw['standard_id'],'standard_version':fw['version'],
        'risk_level':risk,'diagnostic_score':score,'provisional_threshold':threshold,
        'qualification':status,'blocker_count':len(blockers),'blockers':blockers,
        'domains':domain_details,
        'hard_limit':'Input evidence and approval references are unverified assertions. Passing this calculator NEVER activates an agent or authorizes execution.'
    }

def main():
    fw=load_yaml(ROOT/'framework.yaml')
    inp=Path(sys.argv[1]) if len(sys.argv)>1 else ROOT/'examples/assessment_R3_blocked.yaml'
    assessment=load_yaml(inp)
    report=evaluate(fw,assessment)
    print(json.dumps(report,indent=2,ensure_ascii=False))
    return 0 if report['qualification']=='READY_FOR_AUTHORIZED_REVIEW' else 2

if __name__=='__main__':
    try:sys.exit(main())
    except Exception as exc:
        print('ERROR:',exc,file=sys.stderr);sys.exit(1)
