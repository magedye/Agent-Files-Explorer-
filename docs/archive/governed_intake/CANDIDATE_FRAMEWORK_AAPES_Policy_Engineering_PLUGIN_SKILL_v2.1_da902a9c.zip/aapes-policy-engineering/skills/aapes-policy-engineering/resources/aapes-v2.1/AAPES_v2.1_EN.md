# AAPES v2.1 — AI Agent Policy Engineering Standard
**Review candidate | AAPES-STD-002 | v2.1.0-rc.1 | 2026-11-04 | English technical pack**

> **Authority and evidence notice.** This is a proposed internal engineering specification, not an ISO/IEEE/OWASP certification and not proof of deployment readiness. It adapts the previous AAPES v1.0 package and integrates reviewed changes from the user-supplied Arabic AAPES v2.0 draft. A rule declaration or a successful static test cannot approve a live agent.

## 0. Purpose, scope, and controlled outcome

**Purpose:** convert governing intentions into testable requirements, separately enforced authorization checks, traceable evidence and decisions approved by an independent owner. AAPES covers R0 advisory agents through R3 production/mutating agents, including multiple models, tools and delegated agents.

**Normative distinction:** `Rule text != enforcement != verification != approval`. The four stages may refer to one policy but must not be treated as interchangeable. AAPES is not an inference algorithm and does not assume a specific vendor model.

**Decision owners:** Policy Owner (PO) authors policy, Security/Engineering Owner implements the boundary, Independent Reviewer verifies evidence, Authorized Approver accepts residual risk. One individual can hold multiple non-conflicting roles at lower risk, but a mutating agent MUST NOT approve its own high-risk actions.

### 0.1 Governing statuses

| Artifact / state | Meaning |
|---|---|
| `DRAFT` | Unapproved design; no live effect |
| `SPEC_APPROVED` | Specification approved, not implemented |
| `IMPLEMENTED` | Implementation identified; verification may still be absent |
| `VERIFIED_IN_SCOPE` | Specified tests completed and evidence retained; not deployment approval |
| `READY_FOR_AUTHORIZED_REVIEW` | Static qualification passed; authorized human review still required |
| `ACTIVE` | Production platform activated after external authorization, not by these scripts |
| `BLOCKED` | Critical gate failed, missing, or unavailable |
| `INSUFFICIENT_EVIDENCE` | Evidence not available or not independently trusted |

## 1. Normative references and interpretation

The terms `MUST`, `MUST NOT`, `SHOULD`, `SHOULD NOT` and `MAY` are used in the engineering sense of BCP 14 when capitalized. `MUST` is imposed on the **implementer/operating organization**, not directly enforced by word choice inside an LLM. Deviation from `SHOULD` requires an owner-recorded rationale and a compensating approach.

| Reference | Role in AAPES | Non-claim |
|---|---|---|
| ISO/IEC/IEEE 29148:2018 | Requirements quality, traceability, lifecycle | No assertion of full ISO conformity |
| IETF RFC 2119 + RFC 8174 (BCP 14) | Requirement levels | Capitalization does not create model enforcement |
| NIST AI RMF 1.0 and AI 600-1 | Govern, Map, Measure, Manage | Non-prescriptive risk guidance |
| OWASP Agent Control Standard (ACS) | Runtime hooks, authenticated control and traceability | Compatible design direction, not ACS certification |
| OPA Rego / Cedar | Policy decision implementation options | No one engine is mandatory for all deployments |
| JSON Schema 2020-12 | Input syntax and structure validation | Cannot authenticate identity or authorization |
| OpenAI evaluation guidance | Human calibrated testing and graders | Not required for non-OpenAI providers |

## 2. Architecture and security boundaries

```text
Authorized policy owner --> signed/versioned policy registry --> PDP
User / task --> LLM planner --> model-proposed action --> tool schema validator
                                                      |
                                                      v
                                       PEP (outside LLM runtime)
                                      /  |       |       \
                         identity/ACL  approval  PDP  risk limits
                                      \  |       |       /
                                       decision: ALLOW or DENY
                                                      |
                                      ALLOW -> bounded tool execution
                                                      |
                                          real tool-result evidence
                                                      |
                              independent verification + owner approval
```

**Trust guarantees are conditional.** The PEP must be non-bypassable from the agent identity; trusted authorization claims must be derived from an external authentication/approval service, not fields the model can set. Signature/identity verification belongs in a trusted component. Even strict code does not provide absolute protection against compromised infrastructure, incorrect requirements or untested paths.

**Safe default:** for any state-changing operation `DENY` on missing/unknown inputs, PDP outage or expired approval. Low-risk classification tasks may return `INCONCLUSIVE` instead of making up evidence. A tool-schema validator is necessary for shape, not sufficient for authorization.

### 2.1 Risk classes

| Tier | Operation | Candidate threshold* | Minimum deployment expectation |
|---|---|---:|---|
| `R0` | Advisory/no external state-changing tools | 75/100 | Grounded output, scope, safe data handling |
| `R1` | Tool access limited to authorized reads; confidentiality still applies | 80/100 | Read access control, provenance, privacy |
| `R2` | State-changing non-production/staging actions | 85/100 | Non-bypassable PEP, staging tests, recovery plan |
| `R3` | Production, sensitive, finance or irreversible action | 90/100 | Independent approval, scoped credentials, side-effect tests, tamper-evident evidence |

*All thresholds are provisional design targets, not empirically calibrated reliability percentages. R0 or R1 can still present serious confidentiality or downstream decision risks and must be reclassified when warranted.*

## 3. Domain priorities and risk-adjusted weights

The 12 importance weights sum to 100%. They allocate *engineering review attention*; they are not estimated probabilities of failure. Impact multipliers are subjective R0–R3 risk-context factors, distinct from importance. For R2/R3, D08 and D11 become P0 even though their baseline is P1.

| ID | Domain | W (%) | R3 impact | Base priority | Deliverable |
|---|---|---:|---:|---|---|
| D01 | Requirements Engineering | 11 | 1.1 | P0 | Requirements registry and traceable acceptance tests |
| D02 | Formal Semantics and Invariants | 9 | 1.2 | P0 | Three-valued decisions, invariants and executable policies |
| D03 | Instruction Authority and Conflict Resolution | 9 | 1.2 | P0 | Platform authority map and conflict register |
| D04 | Context Engineering and Few-Shot | 5 | 0.8 | P1 | Prompt segmentation and perturbation tests |
| D05 | Trust and Memory Boundaries | 10 | 1.5 | P0 | Untrusted-source labeling and retrieval access controls |
| D06 | Agent Authority and Delegation | 10 | 1.5 | P0 | Least-privilege grants and verifiable approvals |
| D07 | Tool Boundary Enforcement | 13 | 1.5 | P0 | Non-bypassable PEP and schema/authorization validation |
| D08 | Workflow and Recovery Governance | 6 | 1.3 | P1 | State transitions, idempotency and recovery plans |
| D09 | Evidence Provenance and Audit | 9 | 1.1 | P0 | Privacy-preserving tamper-evident audit linkage |
| D10 | Evaluation and Calibration | 9 | 1.2 | P0 | Held-out evaluations and calibrated graders |
| D11 | Adversarial Testing and Resilience | 5 | 1.4 | P1 | Sandbox red-team suites and safe circuit breakers |
| D12 | Lifecycle and Change Governance | 4 | 0.9 | P1 | Approval, provenance, rollback and requalification |

### 3.1 Diagnostic score and veto decision (separate outputs)

For risk class `r`, maturity `M_i` in {0,1,2,3,4}, importance `W_i`, and risk multiplier `I_(r,i)`:

```text
DiagnosticScore_r = 100 * SUM_i(W_i * I_(r,i) * M_i / 4)
                         / SUM_i(W_i * I_(r,i))
```

An appropriately approved `NOT_APPLICABLE` domain may be removed from both sums for R0/R1 only; documented owner rationale is required and prohibited exclusions stay blocking. Never zero out the diagnostic score on veto: publish `score`, `blockers` and `qualification` as different fields. Score alone NEVER authorizes `ACTIVE`.

The qualification decision is `BLOCKED` if any applicable hard gate fails or is untested, critical evidence is stale/absent, R2/R3 P0 maturity is not independently verified at 4, or risk-tier score is below its provisional threshold. A clean calculation leads only to `READY_FOR_AUTHORIZED_REVIEW` if all declarations are present; the assessment tool does not authenticate evidence. A requested deployment still needs authorized external approval and activation checks.

## 4. Atomic normative requirements — 48 stable IDs

IDs `AAPES-REQ-001`–`036` retain the previous AAPES v1.0 domain assignments and are clarified. IDs `037`–`048` add one control per domain. Some v2.0 draft wording is intentionally narrowed to avoid false technical guarantees.

### D01 — Requirements Engineering [11% | P0]

**Operational deliverable:** Requirements registry and traceable acceptance tests.

| Requirement | Level | Testable requirement |
|---|---|---|
| `AAPES-REQ-001` | `MUST` | Register each policy with a unique ID, one primary observable obligation, owner, scope and version. |
| `AAPES-REQ-002` | `MUST` | Define trigger, input, required or prohibited action, and acceptance outcome for every requirement. |
| `AAPES-REQ-003` | `MUST` | Resolve ambiguous adjectives with operational definitions or explicit measurable criteria before approval. |
| `AAPES-REQ-037` | `MUST` | Trace each requirement to its originating authority, tests, enforcement control, evidence and approver. |

### D02 — Formal Semantics and Invariants [9% | P0]

**Operational deliverable:** Three-valued decisions, invariants and executable policies.

| Requirement | Level | Testable requirement |
|---|---|---|
| `AAPES-REQ-004` | `MUST` | Define TRUE, FALSE and UNKNOWN handling for conditions where evidence may be incomplete. |
| `AAPES-REQ-005` | `MUST` | Document safety invariants independently from preferred model behavior. |
| `AAPES-REQ-006` | `MUST` | Deny state-changing actions on missing or unverified prerequisites; do not infer permission from absence of denial. |
| `AAPES-REQ-038` | `MUST` | Represent R2/R3 authorization predicates in a tested external policy or equivalent enforceable code. |

### D03 — Instruction Authority and Conflict Resolution [9% | P0]

**Operational deliverable:** Platform authority map and conflict register.

| Requirement | Level | Testable requirement |
|---|---|---|
| `AAPES-REQ-007` | `MUST` | Document the actual instruction hierarchy of each model platform; never hard-code one vendor hierarchy as universal. |
| `AAPES-REQ-008` | `MUST_NOT` | Promote untrusted documents, tool output, retrieved pages or examples to authority by textual claims alone. |
| `AAPES-REQ-009` | `MUST` | Block only the affected high-risk decision when an authoritative policy conflict remains unresolved. |
| `AAPES-REQ-039` | `MUST` | Maintain a versioned conflict-resolution register recording authority, scope, supersession and owner decision. |

### D04 — Context Engineering and Few-Shot [5% | P1]

**Operational deliverable:** Prompt segmentation and perturbation tests.

| Requirement | Level | Testable requirement |
|---|---|---|
| `AAPES-REQ-010` | `MUST` | Keep governing instructions distinct from retrieved task data and model examples using platform-supported channels. |
| `AAPES-REQ-011` | `MUST_NOT` | Treat EXAMPLE_ONLY content as an authorization or an override of a policy. |
| `AAPES-REQ-012` | `SHOULD` | Evaluate paraphrase, ordering, example and long-context perturbations on held-out cases. |
| `AAPES-REQ-040` | `MUST` | Define a measured context-budget and truncation policy that preserves mandatory controls and source provenance. |

### D05 — Trust and Memory Boundaries [10% | P0]

**Operational deliverable:** Untrusted-source labeling and retrieval access controls.

| Requirement | Level | Testable requirement |
|---|---|---|
| `AAPES-REQ-013` | `MUST` | Mark third-party pages, files, tool outputs and cross-agent messages as untrusted instruction sources. |
| `AAPES-REQ-014` | `MUST` | Enforce identity-based retrieval and memory access; quarantine or reject content that requests authority escalation. |
| `AAPES-REQ-015` | `MUST` | Test indirect prompt injection at every external ingestion and memory-retrieval boundary. |
| `AAPES-REQ-041` | `MUST` | Record provenance, retention, deletion policy and owner for persistent agent memory; TTL must be risk-configured. |

### D06 — Agent Authority and Delegation [10% | P0]

**Operational deliverable:** Least-privilege grants and verifiable approvals.

| Requirement | Level | Testable requirement |
|---|---|---|
| `AAPES-REQ-016` | `MUST` | Grant the agent and each tool the minimum scoped credentials needed, with expiry and revocation. |
| `AAPES-REQ-017` | `MUST_NOT` | Delegate privileges, tool scopes, identity or validity periods broader than those authorized for the parent. |
| `AAPES-REQ-018` | `MUST_NOT` | Allow the agent to mint its own approval or impersonate an authorized approver. |
| `AAPES-REQ-042` | `MUST` | Bind high-risk approvals to actor, exact action, target, scope, expiry and single-use request ID through a trusted service. |

### D07 — Tool Boundary Enforcement [13% | P0]

**Operational deliverable:** Non-bypassable PEP and schema/authorization validation.

| Requirement | Level | Testable requirement |
|---|---|---|
| `AAPES-REQ-019` | `MUST` | Place independent policy enforcement at every side-effecting tool/API boundary, not solely in prompts. |
| `AAPES-REQ-020` | `MUST` | Fail closed for state changes on missing approval, unknown decisions, timeouts or unavailable PDP. |
| `AAPES-REQ-021` | `MUST` | Validate tool input schemas and separately authorize semantics, identity, resource and operation server-side. |
| `AAPES-REQ-043` | `MUST` | Prove by integration test that agent-originated calls cannot bypass the PEP or supply trusted authorization claims. |

### D08 — Workflow and Recovery Governance [6% | P1, P0 for R2/R3]

**Operational deliverable:** State transitions, idempotency and recovery plans.

| Requirement | Level | Testable requirement |
|---|---|---|
| `AAPES-REQ-022` | `MUST` | Define authorized state transitions and recorded checkpoints for multi-step mutating workflows. |
| `AAPES-REQ-023` | `MUST_NOT` | Mark a workflow COMMITTED before required independent post-action verification completes. |
| `AAPES-REQ-024` | `MUST` | Select verified compensation, restore-point recovery or manual recovery according to action reversibility. |
| `AAPES-REQ-044` | `MUST` | Use idempotency keys and replay protection for retried or externally approved mutating actions. |

### D09 — Evidence Provenance and Audit [9% | P0]

**Operational deliverable:** Privacy-preserving tamper-evident audit linkage.

| Requirement | Level | Testable requirement |
|---|---|---|
| `AAPES-REQ-025` | `MUST` | Record trace ID, policy version, trusted decision source and actual tool outcome for consequential actions. |
| `AAPES-REQ-026` | `MUST_NOT` | Claim execution success, rollback completion or approval without event-level corroborating evidence. |
| `AAPES-REQ-027` | `MUST` | Redact credentials and restricted personal data before audit persistence and limit log-reader access. |
| `AAPES-REQ-045` | `MUST` | For R2/R3, use tamper-evident append-only evidence with bounded retention and independent access controls. |

### D10 — Evaluation and Calibration [9% | P0]

**Operational deliverable:** Held-out evaluations and calibrated graders.

| Requirement | Level | Testable requirement |
|---|---|---|
| `AAPES-REQ-028` | `MUST` | Test positive, negative, missing-evidence and conflict cases with reference decisions. |
| `AAPES-REQ-029` | `MUST` | Use deterministic checks when possible and calibrate LLM judges against independently labeled human cases. |
| `AAPES-REQ-030` | `MUST` | Keep held-out tests separate from prompt development and record model/version/configuration for each run. |
| `AAPES-REQ-046` | `MUST` | Define per-risk acceptance thresholds and report denominator, failure types, uncertainty and evaluator disagreement. |

### D11 — Adversarial Testing and Resilience [5% | P1, P0 for R2/R3]

**Operational deliverable:** Sandbox red-team suites and safe circuit breakers.

| Requirement | Level | Testable requirement |
|---|---|---|
| `AAPES-REQ-031` | `MUST` | Exercise adversarial prompt and tool-input tests in an isolated non-production environment. |
| `AAPES-REQ-032` | `MUST` | Use circuit breakers with configurable thresholds that block unsafe actions rather than bypass controls. |
| `AAPES-REQ-033` | `MUST` | Rerun applicable adversarial regression tests after changes to prompts, tools, memory or policy logic. |
| `AAPES-REQ-047` | `MUST` | Document threat coverage and residual risk; zero observed critical failures is not proof of universal safety. |

### D12 — Lifecycle and Change Governance [4% | P1]

**Operational deliverable:** Approval, provenance, rollback and requalification.

| Requirement | Level | Testable requirement |
|---|---|---|
| `AAPES-REQ-034` | `MUST` | Version policies, prompts, tools, model settings and enforcement artifacts with change provenance. |
| `AAPES-REQ-035` | `MUST` | Requalify affected controls when model versions, privileges, tools or trusted data pipelines change. |
| `AAPES-REQ-036` | `MUST_NOT` | Activate R3 capabilities without a verifiable approval from a separately authorized human owner. |
| `AAPES-REQ-048` | `MUST` | Maintain documented emergency suspension, incident response and safe rollback or recovery procedures. |

## 5. Stage gates G0–G7 and owner separation

| Gate | Evidence of completion | Review authority |
|---|---|---|
| `G0` | Scope, task, risk and owner registered | Project owner / intake |
| `G1` | Atomic requirements and decision tables checked | Requirements reviewer |
| `G2` | Platform authority, conflicts and trust boundaries checked | Governance/security reviewer |
| `G3` | Tool boundaries and independent enforcement demonstrated | Implementation/security reviewer |
| `G4` | Behavioral, policy and adversarial tests executed in scope | Independent evaluator |
| `G5` | Evidence traceability, integrity and recovery reviewed | Evidence/recovery reviewer |
| `G6` | Authorized approval or formal risk acceptance recorded | Authorized approver |
| `G7` | Controlled activation, monitoring and emergency stop (post-approval) | Operations owner |

**Gate discipline:** G7 is an operational activation/monitoring step AFTER G6. A static script may inspect a gate declaration but does not pass a real gate. G3 is mandatory for tools with consequential data access; in R0 the absence of tools must be evidenced. A `NOT_RUN` critical gate is not a pass. A signed owner approval does not replace a failing safety control.

## 6. Runtime requirements: implementation contracts

### 6.1 Strict input, authorization binding and delegation

The tool-request JSON Schema in `schemas/tool_action.schema.json` permits only a bounded sample action. A production PEP MUST map actor identity from the server session, independently validate credentials, check per-tool least privilege, confirm an approval bound to actor/action/target/expiry/nonce, prevent replay and reject any request without a current trusted authorization decision.

**DO NOT** accept `approval_valid`, `mfa_verified`, `token_age` or `approver_role` merely because the LLM wrote those keys. The sample Rego policy consumes `input.trusted` values produced by a separate authenticated gateway. Its syntax must be tested with `opa check` and `opa test` before deployment, and its trusted data flow must then be integration-tested.

### 6.2 Persistent memory, tool context and prompt injection

Persistent memory must carry content origin, owner, ACL/tenant scope, retention, timestamps and retrieval provenance. Untrusted retrieval remains *data*, not instructions. Do not claim sanitization removes all malicious instructions; combine input quarantine, source-level filtering, authorization, egress restrictions and adversarial retrieval tests. TTL or context reset thresholds are configurable and measured, not fixed universal numbers.

### 6.3 State machines, idempotency and recovery

A safe mutating workflow follows `PROPOSED -> AUTHORIZED -> EXECUTING -> TOOL_CONFIRMED -> INDEPENDENTLY_VERIFIED -> COMMITTED`. Failure branches go to `BLOCKED`, `COMPENSATING`, `RECOVERY_REQUIRED` or `FAILED`, each with explicit evidence. Saga compensation is *not* inherently a rollback: deleting an inserted record may not undo notifications, financial transfers or external effects. Use tested compensation only for reversible changes; require durable restore points or a human recovery plan for irreversible actions, and prohibit the operation if residual risk is not authorized. Retried mutations must use idempotency keys and replay checks.

### 6.4 Circuit breakers and human approvals

All thresholds (timeouts, consecutive failure count, back-off, alert volume) are service-level configuration items chosen from tests, capacity and safety requirements. When PDP or approval service is unavailable, high-risk actions queue or deny; circuit half-open probes MUST NOT bypass authorization. Human approval requests include exact action, resource, impact radius, before/after diff or hashes, expiry, requester, independent approver, rollback/compensation status and identity/approval reference. Alert aggregation must not confer implied batch approval.

### 6.5 External evidence, logs and confidential reasoning

Verification uses actual tool calls, output objects, execution IDs, policy decisions, immutable/tamper-evident audit records, sampled independent checks and authorized human sign-off. A checksum alone proves neither truthful execution nor that a human approved it. Redact secrets before persistence and apply access controls/retention. Hidden chain-of-thought is neither available nor a compliance proof; verifiable actions and outcomes are primary evidence.

## 7. Evaluation design and acceptance

Use held-out, risk-stratified cases, with positives, negatives, missing evidence, conflict, boundary and prompt-injection attempts. Record full denominator, test data origins, model/version, randomness settings, prompt hash, policy hash, actual tool traces and judge configuration. For policy-critical outcomes prefer deterministic checkers and trusted service logs; for semantic output judges use human-calibrated rubrics, independent labels and disagreement review. Cross-family judges can be a robustness test but are not proof of impartiality. Fixed 10% audits, kappa 0.85 and universal 100%-success claims are NOT requirements of this standard.

**Risk acceptance:** specify zero *observed* critical breaches in the declared critical suite at release qualification; report suite size, coverage, data limits, false rejections and confidence intervals where appropriate. No finite test suite can guarantee universal compliance. R3 requires separate owner approval and actual evidence beyond these reference fixtures.

### 7.1 Minimum evaluation matrix

| Case family | Required observable result |
|---|---|
| Authorized R3 mutation | ALLOW only after trusted principal, target and bound approval verification |
| Missing/expired approval | DENY, no downstream mutation |
| Untrusted injected approval claim | DENY when submitted by model/user |
| PDP timeout/circuit open | DENY or queue with no side effect |
| Conflicting authority claims | BLOCKED_CONFLICT for affected action |
| Incomplete test evidence | INCONCLUSIVE instead of fabricated PASS |
| Retry/replay | One authorized side effect at most |
| Compensation failure | RECOVERY_REQUIRED with trace; not fictitious ROLLED_BACK |
| Memory injection | No promotion of retrieved instruction to privileged command |
| Secret in log payload | Redaction verified without losing traceability |

## 8. Example files and validation scope

| Artifact | Intended use | Explicit limit |
|---|---|---|
| `framework.yaml` | Domain/weights/48 requirements/gates | Normative data, not enforceable by itself |
| `schemas/*.json` | Syntax/type validation for policies, tool actions, approval requests and audit events | No authentication or authorization |
| `rules/*.yaml` | Machine-readable sample policies | Draft specimens only, no approval |
| `policies/*.rego` | Sample Rego v1 default-deny policy | Not connected to an actual PEP/PDP |
| `workflow_reference.yaml` | State transition and recovery reference model | No transactional runner or durable store |
| `tools/reference_guard.py` | Deterministic demonstration of matching trusted claims | Not a production identity or approval verifier |
| `tools/validate_pack.py` | Schema checks + reference fixtures | Not an AI evaluation or live integration test |
| `tools/assess_readiness.py` | Risk-weighted score + veto assessment | Does not authenticate submitted evidence |
| `tests/test_pack.py` | Regression tests including blockers and schema rejection | Uses offline synthetic fixtures |

## 9. Adoption procedure and owner decisions

1. Create a versioned policy registry and record actual platform instruction precedence and user/owner authority.
2. Map actions and data sources to R0–R3; identify side effects, confidential data and irreversibility.
3. Configure trusted identity, independent approval service, bounded credentials and non-bypassable PEP before R2/R3.
4. Create threat-specific test suites and calibrate thresholds from actual workloads rather than copied numbers.
5. Capture trustworthy evidence: environment, code/model/policy commits, tool logs, redaction, independent reviewer and residual risk.
6. Approve specification and deployment separately; activate only through the owner-authorized operational system and monitor changes.

**Release blocker:** until the organization supplies actual owners, key infrastructure, policy engines, tool identities, evidence store, tests and sign-off, `REVIEW_CANDIDATE_NOT_ADOPTED` remains the only justified framework status.

## 10. Source-draft review record (v2.0 -> v2.1)

| Finding | Disposition | Source issue | Applied correction |
|---|---|---|---|
| F01 | Accept with limits | PEP/PDP separation | Bounded server-side enforcement; no claim of universal determinism. |
| F02 | Correct | Invalid/unsupported Rego signature pseudocode | Provide modern Rego example; signature and identity checks reside in trusted upstream verifier. |
| F03 | Correct | Schema cannot prove authorization | Validate shape, then verify identity, action, resource and approval binding outside model. |
| F04 | Correct | Readiness score zeroed on any veto | Preserve diagnostic maturity score; publish independent blockers and qualification. |
| F05 | Conditional | Universal formal-DSL requirement | Require executable policy for consequential actions; use decision tables for low-risk tasks. |
| F06 | Correct | Saga compensation promised as automatic rollback | Use compensations only if safe/tested; otherwise manual recovery or forbid action. |
| F07 | Correct | Fixed 70% context reset and TTL | Make thresholds and retention specific to platform, task and measured risk. |
| F08 | Correct | Cross-family judge as absolute requirement | Prefer deterministic grading; calibrate any model judge against independent ground truth. |
| F09 | Correct | Fixed 10% sample and kappa >=0.85 | Use stratified review, disagreement analysis and risk-specific acceptance thresholds. |
| F10 | Correct | 100% critical tests implies global assurance | Require zero observed critical failures in defined scope, disclose coverage and uncertainty. |
| F11 | Extend | Audit logs described as encrypted/signed | Add tamper-evidence, retention, access separation, redaction and provenance. |
| F12 | Correct | Fixed breaker thresholds and human alert caps | Parameterize operations; degrade by deny/queue, never by silent bulk approvals. |
| F13 | Correct | One hierarchy for all model vendors | Map provider/platform authority; do not claim universal ROOT>... ordering. |
| F14 | Extend | No binding/replay checks for approval ticket | Trusted approval service, scope/expiry/nonce binding, segregation of duties. |
| F15 | Extend | Memory sanitization treated as comprehensive defense | Add provenance, access separation, quarantine, retention and retrieval-time boundary. |
| F16 | Clarify | CoT excluded as evidence | No verification from hidden reasoning; use visible traces and tool/system records. |
| F17 | Clarify | Production-ready label before implementation | Mark reviewed draft; require live integration tests and owner approval. |

## 11. References (verified public primary sources, 2026-11-04)

- **ISO29148:** https://www.iso.org/standard/72089.html
- **BCP14:** https://www.rfc-editor.org/info/bcp14/
- **NIST-AIRMF:** https://www.nist.gov/itl/ai-risk-management-framework
- **NIST-AI6001:** https://www.nist.gov/publications/artificial-intelligence-risk-management-framework-generative-artificial-intelligence
- **OWASP-ACS:** https://genai.owasp.org/resource/agent-control-standard-acs/
- **OPA-REGO:** https://www.openpolicyagent.org/docs/policy-reference/keywords/if
- **OPA-BUILTINS:** https://www.openpolicyagent.org/docs/policy-reference/builtins
- **JSON-SCHEMA:** https://json-schema.org/draft/2020-12/json-schema-core
- **OPENAI-EVALS:** https://developers.openai.com/api/docs/guides/evaluation-best-practices

**Source of AAPES evolution:** previous AAPES v1.0 user package and the user-supplied document `Pasted text(5).txt` titled AAPES v2.0. Proposed changes in that document have been reviewed; not all wording is adopted verbatim.
