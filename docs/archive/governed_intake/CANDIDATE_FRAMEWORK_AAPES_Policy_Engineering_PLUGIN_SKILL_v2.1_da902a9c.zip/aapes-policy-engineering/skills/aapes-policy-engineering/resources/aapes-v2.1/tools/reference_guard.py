#!/usr/bin/env python3
"""AAPES synthetic decision oracle, NOT a production Policy Enforcement Point.

The trusted dictionary in test fixtures is SIMULATED. In a real integration it must
be created inside an authenticated gateway from identity/approval services, not
from agent, end-user, document, or tool arguments.
"""
from pathlib import Path
import json
from jsonschema import Draft202012Validator

ROOT = Path(__file__).resolve().parents[1]
ACTION_SCHEMA = json.loads((ROOT / 'schemas/tool_action.schema.json').read_text(encoding='utf-8'))
VALIDATE_ACTION = Draft202012Validator(ACTION_SCHEMA)
TRUSTED_CLAIMS = (
    'gateway_authenticated', 'principal_authorized', 'approval_verified',
    'approval_action_bound', 'approval_not_expired', 'approval_not_replayed',
    'approver_separate', 'pdp_healthy',
)

def production_write_reference(payload: dict) -> str:
    """Return ALLOW only for an in-scope action and all simulated claims True."""
    action = payload.get('action')
    trusted = payload.get('trusted')
    if not isinstance(action, dict) or not isinstance(trusted, dict):
        return 'DENY'
    if not VALIDATE_ACTION.is_valid(action):
        return 'DENY'
    if not all(trusted.get(k) is True for k in TRUSTED_CLAIMS):
        return 'DENY'
    return 'ALLOW'

def classify_test_evidence(payload: dict) -> str:
    """Report a status, never approve a release. Input is a simulated CI report."""
    if payload.get('evidence_attested') is not True or payload.get('evidence_commit_matches') is not True:
        return 'INCONCLUSIVE'
    if payload.get('verified_required_failure') is True:
        return 'TESTS_FAILED'
    if payload.get('all_required_executed') is True and payload.get('all_required_passed') is True:
        return 'TESTS_PASSED'
    return 'INCONCLUSIVE'

ORACLES = {
    'AAPES-POL-PROD-WRITE-001': production_write_reference,
    'AAPES-POL-TEST-EVIDENCE-001': classify_test_evidence,
}
