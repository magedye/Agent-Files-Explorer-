# v1.3.1 corrective release — 2026-11-06

- Fixed F-01: G5 now validates mandatory task transitive dependency closure and detects missing or cyclic edges.
- Fixed F-02: optional completion-scope classification; unbound unfinished unclassified tasks are `INCONCLUSIVE`, explicitly required unfinished tasks are gaps, and out-of-scope/deferred tasks need a decision reference.
- Fixed F-03: gate-specific structural checks; G1 no longer requires later-stage bindings, G2 no longer requires G5 artifacts.
- Added F-04 diagnostic declared-source instruction inventory (`instruction-audit`) with deliberately unverified native loading/authority.
- Added synthetic negative tests and retained legacy v1.2 scripts/tests unchanged.
- Kept the preexisting contract `agdl-1.3` and historic 1.3.0 verification evidence; regenerated package checksums and patch verification.
- No production enforcement, owner authentication, live Codex/Windows qualification, or target-project activation is claimed.

---

# Changelog

## 1.3.0 — 2026-11-06 — implemented candidate

- Reconciled the supplied plan for one developer, one primary agent and small/medium projects.
- Added English core, 24 classified rules and broad task-bound local autonomy without approval loops.
- Separated native authority, project authority, impact, normative force, attention and activation.
- Preserved the original seven scripts and two test files; reused G1/G2 and explicitly scoped the new G5 profile.
- Added strict local reference/evidence contracts and missing/stale/unknown diagnostics without an acceptance claim.
- Added bounded partial Markdown bridges with byte-preserving raw export and semantic loss reports.
- Added optional dependency/resume diagnostics and a declared-scope classifier, not orchestration or enforcement.
- Added Codex-first and version-specific optional-host guides, inert examples, prompts and proportional templates.
- Added deterministic tests and a narrow synthetic comparison; retained live qualification and efficacy as NOT_RUN.
- No target project, original archive, global host configuration or remote repository was modified.
