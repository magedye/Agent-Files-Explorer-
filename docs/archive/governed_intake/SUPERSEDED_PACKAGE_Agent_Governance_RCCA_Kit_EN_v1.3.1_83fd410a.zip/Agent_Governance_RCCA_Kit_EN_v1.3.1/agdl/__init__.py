"""AG-DLF: offline read-only assurance diagnostics; not an authorization service."""
__version__ = "1.3.1"
