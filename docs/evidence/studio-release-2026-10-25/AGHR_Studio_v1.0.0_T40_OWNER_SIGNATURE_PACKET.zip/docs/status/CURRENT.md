# Active Project Execution State — Derived View

> Updated2026-10-26 Asia/Aden. Git, source and exact custody take precedence.

## Accepted position

Owner now formally accepts T36 and T38 in their Windows/Edge/local Draft and fresh-app pipx scopes. [Current decision](../governance/STUDIO_T37_T40_OWNER_DECISION_2026_10_25.md): add tests until all-server JS/MJS line coverage reaches80%; then close T37 with accepted environmental performance and single-active CP design limitations, freeze T39 and prepare T40 for signature. No performance/concurrency improvements or new product tasks. No public release before owner-signed T40. Unsigned GPG fallback accepted with a visible warning. Earlier Phase4/T25–T29, T30–T33 and T34/T35 Sandbox L2/L3 acceptance retained. T06/T12/T19 remain MOCK-only; real SEC-001 BLOCKED. Reference1.2.0, contracts and E1–E4 preserved. Native Codex/Antigravity REQUIRED / NOT_RUN / NOT_WAIVED; hosted CI NOT_RUN.

## Phase5 — implemented and tested locally

[T30–T33 delivery](../evidence/studio-phase5-2026-10-24/README.md): ten metrics with independent denominators/evidence and raw/grouped/history, two-level project dashboard with six risks, SARIF/JSON/MD and metrics CSV reports, authenticated backend settings with one-use hash-scoped grants and audit. SQLite remains12 tables. Live qualification counts; historical labels cannot restore it. Arabic NO_SKILL_MATCH contributes to recall, without claiming discovery accuracy or execution.

Agent-Files-Explorer has a hash-pinned local-process evaluator profile via --registered-project=agent-files-explorer. Actual3-run observation measurement:1→1/delta0, not an improvement claim. Additive-schema evaluator runs positive/negative examples, authority/scope rejection and actual L1 generation/PRIN-007. It blocks unsupported policies/tools/closed-schema replacements and still requires distinct Draft reviews.

Verification: complete baseline npm test149/149 on V2; final affected-scope27/27 on V3; earlier focused20/20. Actual isolated Edge four AR/EN screens at four widths, browser SARIF download and source/state Sentinel. The first full run was explicitly cancelled. V2 completed unchanged; V3 only corrects historical-version, execution-window and language metric correlation, with changed lifecycle/Phase5 integration rerun and saved real-runtime metric replay. Unchanged engine evidence is inherited; no claim that every baseline test ran on V3 bytes.

## Boundaries / exact next action

Missing observations remain null/NOT_RUN. Current critical-path coverage0/3; no Active adoption level is granted. GPG enrollment NOT_CONFIGURED. Resource settings expose pinned600s/3600s/2GiB; changes need an engine CP. No canonical/reference/state writes, default owner DB tests, source apply or publishing. No Phase5 owner/release/independent acceptance self-granted.

T34/T35: [PASS_FOR_SANDBOX_LOCAL_PROFILE](../evidence/studio-pilots-2026-10-25/README.md), formally accepted by the current owner instruction. Actual L2 instruction-only and L3 registered P0 SQL procedure, scoped12-table Draft CP/JCS/403/412, protected local Git/CI and CI-only state after merge. L3 has actual3eval+3qualify,7honesty+8scenarios, zero observed false success0/11. Exact frozen product217files; final npm151/151, real Edge AR/EN/RTL and204-file source/state/runtime Sentinel. CRLF, hook-timeout, resume and test-metadata failures remain recorded. Reference1.2.0/E1–E4 and unrelated owner work preserved. GPG unsigned warning owner-accepted; no native/hosted qualification.

T37 [CLOSED_BY_OWNER_CRITERIA](../evidence/studio-release-2026-10-25/T37_CLOSURE.json):83.44%JS/MJS lines4642/5563 across61backend files; no old coverage fragments. npm169tests/168pass/1stale INBOX receipt failure; corrected custody-only test1/1 plus3/3 new legacy cases. Evidence is composed, not a final full-green npm claim. All23old INBOX files unchanged; one pre-existing24th addition pinned without adoption. Frozen source568files; accepted T38wheel unchanged. [T39](../evidence/studio-release-2026-10-25/T39_INDEPENDENT_REVIEW.md):APPROVEfor exact local Draft candidate, separate agent context with same-infrastructure limits. [T40](../evidence/studio-release-2026-10-25/T40_REPORT_AR.md) READY_FOR_OWNER_SIGNATURE; receipt/ZIP in same folder. Exact next: owner decision/signature, then STOP. npm audit two High dev packages, production-only0; [known gaps](../evidence/studio-release-2026-10-25/KNOWN_LIMITATIONS_AR.md) retain Python/native/hosted/production/signature and disabled legacy evaluation limits. No root commit/push/reset or public release.
